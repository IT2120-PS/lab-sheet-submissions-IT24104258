setwd("C:\\Users\\DOWNLOAD\\Desktop\\IT24104258")
getwd()


# Exercise: baking time sample and test (one-sided: mean < 46)

set.seed(123)            # for reproducibility
n <- 25
mu0 <- 46               # null hypothesis mean
pop_sigma <- 2          # given population standard deviation
true_mean <- 45         # the assumed distribution mean for generating sample

# i) generate random sample
sample_times <- rnorm(n, mean = true_mean, sd = pop_sigma)
print("Sample (25 baking times):")
print(round(sample_times, 4))

# sample statistics
xbar <- mean(sample_times)
s_sample <- sd(sample_times)
cat("\nSample mean =", round(xbar,4), "\n")
cat("Sample sd   =", round(s_sample,4), "\n")

# ii) Hypothesis test: H0: mu = 46  vs  H1: mu < 46 at alpha = 0.05
# Since population sd is given (sigma = 2), perform a z-test:
z <- (xbar - mu0) / (pop_sigma / sqrt(n))
p_value_z <- pnorm(z)   # one-sided lower-tail p-value

cat("\nZ-test (sigma known = ", pop_sigma, ")\n", sep = "")
cat(" z =", round(z,4), "\n")
cat(" p-value (one-sided) =", format.pval(p_value_z, digits=6), "\n")

# For comparison, also run the t-test (R's t.test uses sample sd)
cat("\nT-test (using sample sd) - for comparison:\n")
print(t.test(sample_times, mu = mu0, alternative = "less"))
